drop database record;
create database record;
use record;

create Table Restaurant(
restaurant_id int not null Primary Key,
restaurant_name varchar(50),
location varchar(250),
contact_number varchar(250)
);
INSERT INTO Restaurant values(00100,'abc','lahore','11000');
INSERT INTO Restaurant values(00200,'pizza hut', 'lahore','12000');
INSERT INTO Restaurant values(00300,'momwsland', 'lahore','12000');
INSERT INTO Restaurant values(00400,'kfc', 'karachi','14000');
INSERT INTO Restaurant values(00500,'macdlond','lahore','15000');
INSERT INTO Restaurant values(00600,'moms', 'lahore','16000');
INSERT INTO Restaurant values(00700,'eatme', 'lahore','17000');
INSERT INTO Restaurant values(00800,'burger lab', 'lahore','18000');
INSERT INTO Restaurant values(00900,'foodcort', 'lahore','19000');
INSERT INTO Restaurant values(01000,'khana','lahore','20000');
-- for table view

select *from Restaurant;

-- view names of restranant
select restaurant_name from Restaurant;

-- update values from restranant
UPDATE Restaurant
SET location = 'sheikhpura', contact_number ='21212'
where restaurant_id=00900;

-- nested query
SELECT restaurant_name, location, restaurant_id
FROM Restaurant
WHERE restaurant_id =
(SELECT restaurant_id
FROM Restaurant
WHERE restaurant_name ='moms');

-- sql query for like operator retrieve all record from foodcourt
SELECT *
FROM Restaurant
WHERE restaurant_name LIKE 'foodcort';

-- 1 sql query for joins employee and Restaurant
-- retireve all reocrds and all employee will join with every retarant
select * from Restaurant cross join Employee;

create Table Menu_Item(
item_id int not null Primary Key,
item_name varchar(50),
price int,
description varchar(50),
restaurant_id int,
foreign key (restaurant_id) REFERENCES Restaurant(restaurant_id)
);
INSERT INTO Menu_Item values(1,'pizza',100,'not add',00100);
INSERT INTO Menu_Item values(2,'salad',200,'raita add',00200);
INSERT INTO Menu_Item values(3,'burger',250,'egg not allowed',00300);
INSERT INTO Menu_Item values(4,'sandwich',100,'not',00400);
INSERT INTO Menu_Item values(5,'tikaboti',150,'no addition',00500);
INSERT INTO Menu_Item values(6,'barbieque',170,'roti add',00600);
INSERT INTO Menu_Item values(7,'sharwma',190,'spicy',00700);
INSERT INTO Menu_Item values(8,'russian',100,'apples add',00800);
INSERT INTO Menu_Item values(9,'chines',300,'no addtion',00900);
INSERT INTO Menu_Item values(10,'biryni',360,'no addtion',01000);
-- for table view
select *from Menu_Item;

-- display menu from menu table
select item_name from Menu_Item;

-- placing order chines

select *from Menu_Item
where item_id=9;

-- update order items

UPDATE Menu_Item
SET item_name = 'steak', price =1500
where item_id=10;

-- delete from manu items
delete from Menu_Item
where item_id='4';
-- nested query
-- this will show info about decription and price where item name is biryani
SELECT description,price
FROM Menu_Item
WHERE item_id =
(SELECT item_id
FROM Menu_Item
WHERE item_name ='steak');
--  and sql query for operations
SELECT *
FROM Menu_Item
WHERE price BETWEEN 100 AND 250;

create table Customer(
customer_id int not null Primary Key,
customer_name varchar(50),
contact_number varchar (50),
address varchar(50)
);
INSERT INTO Customer values(000010,'manzar','000001','mustwa_towm');
INSERT INTO Customer values(000020, 'ayesha','000002','johar_towm');
INSERT INTO Customer values(000030, 'zonia','000003','qalma_towm');
INSERT INTO Customer values(000040, 'ahsan','000004','mustwa_towm');
INSERT INTO Customer values(000050, 'laiba','000005','johar_towm');
INSERT INTO Customer values(000060, 'rimsha','000006','pindi_towm');
INSERT INTO Customer values(000070, 'muneeb','000007','iqbal_towm');
INSERT INTO Customer values(000080, 'sibgha','000008','mustwa_towm');
INSERT INTO Customer values(000090, 'rabia','000009','johar_towm');
INSERT INTO Customer values(001000, 'mahak','000010','mustwa_towm');

-- view all customers details
select*from Customer;

-- for view  customer_name
select  customer_name from Customer ;

 UPDATE Customer
SET customer_name = 'sobia', address ='qalma_towm'
where customer_id=000030;

-- retirve record about customer sibgha and mahak
select*from
 Customer
where customer_name='sibgha' or address='mustwa_towm'
and customer_name='mahak' and address='mustwa_towm';

-- sql operations on customer
SELECT * FROM Customer
WHERE NOT address='johar_towm';

-- fetch contect number between 000009 and 000004
SELECT *
FROM Customer
WHERE contact_number IN ('000009', '000004');

SELECT item_name,description
FROM Menu_Item
WHERE restaurant_id =
(SELECT restaurant_id
FROM Restaurant
WHERE restaurant_id =00800);

create table orders(
order_id int Primary Key,
order_date varchar(50),
total_amount varchar(50),
customer_id int,
foreign key (customer_id) REFERENCES Customer(customer_id)
);
INSERT INTO orders values(001,'03/11/2021', '100',000010);
INSERT INTO orders values(002,'04/11/2021','200',000020);
INSERT INTO orders values(003,'02/11/2021','250',000030);
INSERT INTO orders values(004,'01/11/2021','400',000040);
INSERT INTO orders values(005,'07/11/2021','500',000050);
INSERT INTO orders values(006,'06/11/2021','600',000060);
INSERT INTO orders values(007,'05/11/2021','700',000070);
INSERT INTO orders values(008,'09/11/2021','1800',000080);
INSERT INTO orders values(009,'08/11/2021','190',000090);
INSERT INTO orders values(010,'01/11/2021', '2000',001000);

-- for table view
select *from orders;

-- view order date from orders

select order_date from orders
where order_id=010;

-- or operation on orders
SELECT *
FROM orders
WHERE order_date = '09/11/2021' OR order_date = '01/12/2021';

-- delete order_id
delete from orders where order_id =3;

create table Employee(
employee_id int Primary Key,
employee_name varchar(50),
contact_number varchar(50),
address varchar(50)
);
INSERT INTO Employee values(0001,'ayeza','00000100','123 Main Street');
INSERT INTO Employee values(0002, 'maryam','00000200','124 Main Street');
INSERT INTO Employee values(0003, 'amina','00000300','125 Main Street');
INSERT INTO Employee values(0004, 'farooq','00000400','126 Main Street');
INSERT INTO Employee values(0005, 'umer','00000500','127 Main Street');
INSERT INTO Employee values(0006, 'asif','00000600','128 Main Street');
INSERT INTO Employee values(0007, 'gul','00000700','129 Main Street');
INSERT INTO Employee values(0008, 'arshad','00000800','122 Main Street');
INSERT INTO Employee values(0009, 'aslam','00000900','131 Main Street');
INSERT INTO Employee values(0100, 'tariq','00001000','133 Main Street');
-- table view
SELECT * FROM Employee;

-- view employee_IDS
select employee_id from Employee;

-- and  operation on employee
SELECT * FROM Employee
WHERE contact_number = '00000800' and employee_name = 'arshad';

-- delete record of employee
delete from Employee
where employee_id= '0003';

-- chnage location of employee
UPDATE Employee
SET employee_name = 'aslam', address ='skp Main Street'
where employee_id=0009;
